/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.patientcategory;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ntobe
 */
public class BedManagementTest {
    
    public BedManagementTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of registerPatient method, of class BedManagement.
     */
    @Test
    public void testRegisterPatient() {
        System.out.println("registerPatient");
        Patient patient = null;
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.registerPatient(patient);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchPatient method, of class BedManagement.
     */
    @Test
    public void testSearchPatient() {
        System.out.println("searchPatient");
        String patientId = "";
        BedManagement instance = new BedManagement();
        Patient expResult = null;
        Patient result = instance.searchPatient(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updatePatient method, of class BedManagement.
     */
    @Test
    public void testUpdatePatient() {
        System.out.println("updatePatient");
        String patientId = "";
        String newFirstName = "";
        String newLastName = "";
        int newAge = 0;
        String newCondition = "";
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.updatePatient(patientId, newFirstName, newLastName, newAge, newCondition);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletePatient method, of class BedManagement.
     */
    @Test
    public void testDeletePatient() {
        System.out.println("deletePatient");
        String patientId = "";
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.deletePatient(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPatients method, of class BedManagement.
     */
    @Test
    public void testGetPatients() {
        System.out.println("getPatients");
        BedManagement instance = new BedManagement();
        List<Patient> expResult = null;
        List<Patient> result = instance.getPatients();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of allocateBed method, of class BedManagement.
     */
    @Test
    public void testAllocateBed() {
        System.out.println("allocateBed");
        String patientId = "";
        String bedId = "";
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.allocateBed(patientId, bedId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of releaseBed method, of class BedManagement.
     */
    @Test
    public void testReleaseBed() {
        System.out.println("releaseBed");
        String bedId = "";
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.releaseBed(bedId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isBedOccupied method, of class BedManagement.
     */
    @Test
    public void testIsBedOccupied() {
        System.out.println("isBedOccupied");
        String bedId = "";
        BedManagement instance = new BedManagement();
        boolean expResult = false;
        boolean result = instance.isBedOccupied(bedId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayWardLayout method, of class BedManagement.
     */
    @Test
    public void testDisplayWardLayout() {
        System.out.println("displayWardLayout");
        BedManagement instance = new BedManagement();
        instance.displayWardLayout();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAvailableBeds method, of class BedManagement.
     */
    @Test
    public void testGetAvailableBeds() {
        System.out.println("getAvailableBeds");
        BedManagement instance = new BedManagement();
        List<String> expResult = null;
        List<String> result = instance.getAvailableBeds();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupiedBeds method, of class BedManagement.
     */
    @Test
    public void testGetOccupiedBeds() {
        System.out.println("getOccupiedBeds");
        BedManagement instance = new BedManagement();
        List<String> expResult = null;
        List<String> result = instance.getOccupiedBeds();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupiedBedsCount method, of class BedManagement.
     */
    @Test
    public void testGetOccupiedBedsCount() {
        System.out.println("getOccupiedBedsCount");
        BedManagement instance = new BedManagement();
        int expResult = 0;
        int result = instance.getOccupiedBedsCount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupancyPercentage method, of class BedManagement.
     */
    @Test
    public void testGetOccupancyPercentage() {
        System.out.println("getOccupancyPercentage");
        BedManagement instance = new BedManagement();
        double expResult = 0.0;
        double result = instance.getOccupancyPercentage();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

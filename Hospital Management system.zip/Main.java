/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.patientcategory;

/**
 *
 * @author ntobe
 */
import java.util.Scanner;

public class Main {
    private static final BedManagement manager = new BedManagement();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n===== MEDICARE HOSPITAL ADMISSION SYSTEM =====");
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. Allocate Bed");
            System.out.println("6. Release Bed");
            System.out.println("7. View Ward Layout");
            System.out.println("8. Generate Reports");
            System.out.println("9. Exit");
            System.out.print("Select an option: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1 -> registerPatientUI();
                    case 2 -> searchPatientUI();
                    case 3 -> updatePatientUI();
                    case 4 -> deletePatientUI();
                    case 5 -> allocateBedUI();
                    case 6 -> releaseBedUI();
                    case 7 -> manager.displayWardLayout();
                    case 8 -> generateReportsUI();
                    case 9 -> exit = true;
                    default -> System.out.println("Invalid choice. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }
    }

    private static void registerPatientUI() {
        System.out.print("Enter Patient ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter First Name: ");
        String fName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lName = scanner.nextLine();
        System.out.print("Enter Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter Gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter Medical Condition: ");
        String condition = scanner.nextLine();

        System.out.println("Select Category: 1. Inpatient  2. Outpatient  3. Emergency");
        int catChoice = Integer.parseInt(scanner.nextLine());

        Patient patient;
        patient = switch (catChoice) {
            case 1 -> new Inpatient(id, fName, lName, age, gender, condition, null, null);
            case 2 -> new Patient(id, fName, lName, age, gender, condition, PatientCategory.OUTPATIENT);
            default -> new Patient(id, fName, lName, age, gender, condition, PatientCategory.EMERGENCY);
        };

        if (manager.registerPatient(patient)) {
            System.out.println("Patient registered successfully!");
        }
    }

    private static void searchPatientUI() {
        System.out.print("Enter Patient ID to search: ");
        String id = scanner.nextLine();
        Patient p = manager.searchPatient(id);
        if (p != null) {
            System.out.println("\n--- Patient Found ---");
            p.displayDetails();
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void updatePatientUI() {
        System.out.print("Enter Patient ID to update: ");
        String id = scanner.nextLine();
        if (manager.searchPatient(id) == null) {
            System.out.println("Patient not found.");
            return;
        }
        System.out.print("Enter New First Name: ");
        String fName = scanner.nextLine();
        System.out.print("Enter New Last Name: ");
        String lName = scanner.nextLine();
        System.out.print("Enter New Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter New Medical Condition: ");
        String condition = scanner.nextLine();

        if (manager.updatePatient(id, fName, lName, age, condition)) {
            System.out.println("Patient updated successfully!");
        }
    }

    private static void deletePatientUI() {
        System.out.print("Enter Patient ID to delete: ");
        String id = scanner.nextLine();
        if (manager.deletePatient(id)) {
            System.out.println("Patient deleted successfully!");
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void allocateBedUI() {
        System.out.print("Enter Patient ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Bed ID (e.g., B01): ");
        String bedId = scanner.nextLine();

        if (manager.allocateBed(id, bedId)) {
            System.out.println("Bed allocated successfully!");
        }
    }

    private static void releaseBedUI() {
        System.out.print("Enter Bed ID to release (e.g., B01): ");
        String bedId = scanner.nextLine();

        if (manager.releaseBed(bedId)) {
            System.out.println("Bed released successfully!");
        } else {
            System.out.println("Bed is either invalid or not currently occupied.");
        }
    }

    private static void generateReportsUI() {
        System.out.println("\n===== WARD & PATIENT REPORTS =====");
        System.out.println("--- All Registered Patients ---");
        for (Patient p : manager.getPatients()) {
            p.displayDetails();
            System.out.println("--------------------");
        }

        System.out.println("\nTotal Registered Patients: " + manager.getPatients().size());
        System.out.println("Available Beds: " + manager.getAvailableBeds());
        System.out.println("Occupied Beds: " + manager.getOccupiedBeds());
        System.out.println("Total Occupied Beds: " + manager.getOccupiedBedsCount());
        System.out.printf("Ward Occupancy Percentage: %.2f%%\n", manager.getOccupancyPercentage());
    }
}

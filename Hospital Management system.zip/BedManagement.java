/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.patientcategory;

/**
 *
 * @author ntobe
 */
import java.util.ArrayList;
import java.util.List;

public class BedManagement {
    private final List<Patient> patients = new ArrayList<>();
    private final String[][] wardBeds = new String[4][5]; // 4x5 layout (20 beds)
    private static final String WARD_NUMBER = "Ward 1";

    public BedManagement() {
        // Initialize bed IDs (B01 to B20)
        int bedNum = 1;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                wardBeds[r][c] = String.format("B%02d", bedNum++);
            }
        }
    }

    // --- Patient Management ---
    public boolean registerPatient(Patient patient) {
        if (searchPatient(patient.getPatientId()) != null) {
            System.out.println("Error: Patient ID already exists.");
            return false;
        }
        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    public boolean updatePatient(String patientId, String newFirstName, String newLastName, int newAge, String newCondition) {
        Patient p = searchPatient(patientId);
        if (p == null) return false;

        p.setFirstName(newFirstName);
        p.setLastName(newLastName);
        p.setAge(newAge);
        p.setMedicalCondition(newCondition);
        return true;
    }

    public boolean deletePatient(String patientId) {
        Patient p = searchPatient(patientId);
        if (p == null) return false;

        if (p instanceof Inpatient inpatient) {
            if (inpatient.getBedNumber() != null) {
                releaseBed(inpatient.getBedNumber());
            }
        }
        return patients.remove(p);
    }

    public List<Patient> getPatients() {
        return patients;
    }

    // --- Bed Management ---
    public boolean allocateBed(String patientId, String bedId) {
        Patient p = searchPatient(patientId);
        if (p == null) {
            System.out.println("Error: Patient not found.");
            return false;
        }
        if (!(p instanceof Inpatient)) {
            System.out.println("Error: Only Inpatients can be allocated a bed.");
            return false;
        }

        Inpatient inpatient = (Inpatient) p;
        if (inpatient.getBedNumber() != null) {
            System.out.println("Error: Patient already has a bed assigned (" + inpatient.getBedNumber() + ").");
            return false;
        }

        if (isBedOccupied(bedId)) {
            System.out.println("Error: Bed " + bedId + " is already occupied.");
            return false;
        }

        if (getOccupiedBedsCount() >= 20) {
            System.out.println("Error: All beds are occupied.");
            return false;
        }

        boolean found = false;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (wardBeds[r][c].equalsIgnoreCase(bedId)) {
                    inpatient.setWardNumber(WARD_NUMBER);
                    inpatient.setBedNumber(wardBeds[r][c]);
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            System.out.println("Error: Invalid Bed ID.");
            return false;
        }

        return true;
    }

    public boolean releaseBed(String bedId) {
        for (Patient p : patients) {
            if (p instanceof Inpatient inp) {
                if (bedId.equalsIgnoreCase(inp.getBedNumber())) {
                    inp.setBedNumber(null);
                    inp.setWardNumber(null);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isBedOccupied(String bedId) {
        for (Patient p : patients) {
            if (p instanceof Inpatient inp) {
                if (bedId.equalsIgnoreCase(inp.getBedNumber())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void displayWardLayout() {
        System.out.println("\n--- Ward Layout (4x5) ---");
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                String bedId = wardBeds[r][c];
                if (isBedOccupied(bedId)) {
                    System.out.print("[OCC] ");
                } else {
                    System.out.print(bedId + " ");
                }
            }
            System.out.println();
        }
    }

    public List<String> getAvailableBeds() {
        List<String> avail = new ArrayList<>();
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                String b = wardBeds[r][c];
                if (!isBedOccupied(b)) {
                    avail.add(b);
                }
            }
        }
        return avail;
    }

    public List<String> getOccupiedBeds() {
        List<String> occupied = new ArrayList<>();
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                String b = wardBeds[r][c];
                if (isBedOccupied(b)) {
                    occupied.add(b);
                }
            }
        }
        return occupied;
    }

    public int getOccupiedBedsCount() {
        return getOccupiedBeds().size();
    }

    public double getOccupancyPercentage() {
        return (getOccupiedBedsCount() / 20.0) * 100.0;
    }
}
